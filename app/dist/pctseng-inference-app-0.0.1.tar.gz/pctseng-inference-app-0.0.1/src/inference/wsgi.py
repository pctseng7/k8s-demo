from inference.app_server import Server

app = Server('inferencing engine').app